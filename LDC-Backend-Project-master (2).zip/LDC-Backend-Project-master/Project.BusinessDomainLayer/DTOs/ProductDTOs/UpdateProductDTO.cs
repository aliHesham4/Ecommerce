﻿
namespace Project.BusinessDomainLayer.DTOs
{
    public class UpdateProductDTO : BaseProductDTO
    {
    }
}
