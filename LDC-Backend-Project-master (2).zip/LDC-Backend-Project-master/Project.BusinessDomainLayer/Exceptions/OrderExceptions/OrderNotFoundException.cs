﻿
namespace Project.BusinessDomainLayer.Exceptions.OrderExceptions
{
    public class OrderNotFoundException (string message) : Exception(message)
    {
    }
}
