﻿
namespace Project.BusinessDomainLayer.Exceptions.ProductExceptions
{
    public class InvalidProductIdException(string message) : Exception (message)
    {
    }
}
