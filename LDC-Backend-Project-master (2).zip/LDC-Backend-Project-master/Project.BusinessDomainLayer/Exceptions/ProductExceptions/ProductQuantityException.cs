﻿
namespace Project.BusinessDomainLayer.Exceptions.ProductExceptions
{
    public class ProductQuantityException (string message) : Exception(message)
    {
    }
}
