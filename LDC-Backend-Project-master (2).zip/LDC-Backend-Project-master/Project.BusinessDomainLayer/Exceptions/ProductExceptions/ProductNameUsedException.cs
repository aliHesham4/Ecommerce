﻿
namespace Project.BusinessDomainLayer.Exceptions.ProductExceptions
{
    public class ProductNameUsedException(string message) : Exception(message)
    {
    }
}
