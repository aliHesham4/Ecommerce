﻿
namespace Project.BusinessDomainLayer.Exceptions.ProductExceptions
{
    public class ProductNotFoundException(string message) : Exception(message)
    {
    }
}
