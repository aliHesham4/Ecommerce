﻿
namespace Project.BusinessDomainLayer.Exceptions.CustomerExceptions
{
    public class UsedEmailException(string message) : Exception(message)
    {
    }
}
