﻿
namespace Project.BusinessDomainLayer.Exceptions.CustomerExceptions
{
    public class AuthenticationException(string message) : Exception(message)
    {
    }
}
