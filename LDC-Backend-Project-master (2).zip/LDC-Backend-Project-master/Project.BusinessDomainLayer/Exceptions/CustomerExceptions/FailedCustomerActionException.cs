﻿
namespace Project.BusinessDomainLayer.Exceptions.CustomerExceptions
{
    public class FailedCustomerActionException (string message) : Exception(message)
    {
    }
}
