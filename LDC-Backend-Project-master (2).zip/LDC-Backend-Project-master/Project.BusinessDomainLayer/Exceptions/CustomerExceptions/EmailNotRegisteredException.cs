﻿
namespace Project.BusinessDomainLayer.Exceptions.CustomerExceptions
{
    public class EmailNotRegisteredException(string message) : Exception(message)
    {
    }
}
