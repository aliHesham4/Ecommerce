﻿
namespace Project.BusinessDomainLayer.Exceptions.CustomerExceptions
{
    public class InvalidCustomerIdException (string message) : Exception(message)
    {
    }
}
