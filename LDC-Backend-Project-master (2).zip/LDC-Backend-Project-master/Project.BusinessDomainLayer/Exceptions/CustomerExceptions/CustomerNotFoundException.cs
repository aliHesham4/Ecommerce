﻿
namespace Project.BusinessDomainLayer.Exceptions.CustomerExceptions
{
    public class CustomerNotFoundException(string message) : Exception(message)
    {
    }
}
