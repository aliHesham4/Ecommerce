﻿using System.ComponentModel.DataAnnotations;

namespace Project.BusinessDomainLayer.VMs
{
    public class ProductVM : BaseProductVM
    {

    }
}
