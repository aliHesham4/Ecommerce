﻿
namespace Project.BusinessDomainLayer.VMs
{
    public class OrderItemVM : BaseOrderItemVM
    {
    }
}
